#!/bin/bash

# Define the version
VERSION="v0.1.0"

# Define the function to display the command's usage
usage() {
  echo "Usage: internsctl [options]"
  echo "Options:"
  echo "  cpu getinfo          Display CPU information similar to 'lscpu'"
  echo "  memory getinfo       Display memory information similar to 'free'"
  echo "  user create <username>  Create a new user and their home directory"
  echo "  user list [--sudo-only]  List all users or users with sudo permissions"
  echo "  file getinfo [options] <file-name>  Get information about a file"
  echo "  --help                Display usage information"
  echo "  --version             Display the version of the command"
  echo "File getinfo options:"
  echo "  --size, -s            Print file size"
  echo "  --permissions, -p     Print file permissions"
  echo "  --owner, -o           Print file owner"
  echo "  --last-modified, -m   Print last modified time"
}

# Function to create a new user
create_user() {
  if [ $# -ne 1 ]; then
    echo "Usage: internsctl user create <username>"
    return 1
  fi

  username="$1"
  useradd -m "$username"
}

# Function to list users
list_users() {
  if [ "$1" == "--sudo-only" ]; then
    getent passwd | cut -d: -f1,4 | awk -F: '$2 >= 1000 && $2 < 65534' | cut -d: -f1
  else
    getent passwd | cut -d: -f1
  fi
}

# Function to get file information
get_file_info() {
  if [ $# -lt 2 ]; then
    echo "Usage: internsctl file getinfo [options] <file-name>"
    return 1
  fi

  local options=()
  local file=""
  
  # Parse options
  while [[ "$1" == --* || "$1" == -* ]]; do
    options+=("$1")
    shift
  done

  # Process options
  for opt in "${options[@]}"; do
    case $opt in
      --size|-s)
        size=$(stat -c "%s" "$file")
        echo "Size(B): $size"
        ;;
      --permissions|-p)
        access=$(stat -c "%A" "$file")
        echo "Access: $access"
        ;;
      --owner|-o)
        owner=$(stat -c "%U" "$file")
        echo "Owner: $owner"
        ;;
      --last-modified|-m)
        modify=$(stat -c "%y" "$file")
        echo "Modify: $modify"
        ;;
      *)
        echo "Unrecognized option: $opt"
        ;;
    esac
  done

  # Print the filename
  filename=$(basename "$file")
  echo "File: $filename"
}

# Check for command-line arguments
if [ "$1" == "cpu" ] && [ "$2" == "getinfo" ]; then
  get_cpu_info
elif [ "$1" == "memory" ] && [ "$2" == "getinfo" ]; then
  get_memory_info
elif [ "$1" == "user" ] && [ "$2" == "create" ]; then
  create_user "$3"
elif [ "$1" == "user" ] && [ "$2" == "list" ]; then
  list_users "$3"
elif [ "$1" == "file" ] && [ "$2" == "getinfo" ]; then
  get_file_info "$@"  # Pass all arguments to the function
elif [ "$1" == "--help" ]; then
  usage
elif [ "$1" == "--version" ]; then
  echo "internsctl $VERSION"
else
  echo "Custom Linux command 'internsctl' - Your operation here."
fi
